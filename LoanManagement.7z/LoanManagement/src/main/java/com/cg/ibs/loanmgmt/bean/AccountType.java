package com.cg.ibs.loanmgmt.bean;

public enum AccountType {
	SAVINGS, FIXED_DEPOSIT, RECURRING_DEPOSIT, JOINT_SAVINGS;
}
