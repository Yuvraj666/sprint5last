package com.cg.ibs.loanmgmt.bean;

public enum AccountHoldingType {
	PRIMARY, SECONDARY, INDIVIDUAL;
}
