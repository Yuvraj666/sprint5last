package com.cg.ibs.loanmgmt.bean;

public enum Gender {
	MALE, FEMALE, PREFER_NOT_TO_SAY;
}
